<div class="col-md-4 col-sm-4">
	<div class="row part-footer">
		<div class="col-md-3 col-xs-3"><img src="images/address.png"> </div>
		<div class="col-md-9 col-xs-9 text-left foot-text"> <h3>ADDRESS </h3> <p>No. 63/64, Bahosi Housing Estate, <br>Lanmadaw Township, 11131, Yangon, Myanmar </p></div>
		<div class="clear"> </div>
	</div>
</div>

<div class="col-md-4 col-sm-4 part-footer">
	<div class="row">
		<div class="col-md-3 col-xs-3 foot-icon"><img src="images/reservation.png"> </div>
		<div class="col-md-9 col-xs-9 text-left foot-text"> <h3> CONTACT INFORMATIONS</h3> <p>  <a href="#popup" id="my-button">inquiry@hotelbahosi.com</a>  <br>+95 (1) 223589, +95 (1) 223587</p></div>
		<div class="clear"> </div>
	</div>
</div>
<div class="col-md-4 col-sm-4 part-footer">
	<div class="row">
		<div class="col-md-3 col-xs-3 foot-icon"><img src="images/sayintouch.png"> </div>
		<div class="col-md-9 col-xs-9 text-left foot-text"> <h3> STAY IN TOUCH</h3> <p><a href="https://www.facebook.com/hotelbahosi" target="_blank"> facebook.com/hotelbahosi</a><br><a href="http://www.tripadvisor.com/Hotel_Review-g294191-d6484370-Reviews-Hotel_Bahosi-Yangon_Rangoon_Yangon_Region.html" target="_blank"> tripadvisor.com/hotelbahosi</a></p></div>
	</div>
</div>